import sys
import socket

clientSocket = socket.socket()
try:
    host = sys.argv[1]
except:
    host = ''
try:
    port = sys.argv[2]
except:
    port = 8889

# Connecting
clientSocket.connect((host, port))
print 'Connected to %s:%s' % (host, port)

while True:
    message = raw_input("You: ")
    clientSocket.send(message)